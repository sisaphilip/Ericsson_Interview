using System;
using System.Collections.Generic;

namespace spacethree
{
    class three {         
        static void Main(string[] args)
        {
/////////////part 1   //////////////////////////////////////////////////////////////////////

//Console.WriteLine("   " );
//
//command to set freq               viPrintf "(..., "SOUR:FREQ 2GHz\n")"
//command ot set output dbm        "viPrintf (..., "SOUR:POW -20dBm\n")"

//output on                         :OUTPut<hw>[:STATe] >>>>>>>OUTP ON  








//////still working on this/////////////////////////////////////////////

	}
    }
}

